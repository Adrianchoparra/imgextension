chrome.storage.sync.get('cursor', ({cursor}) => {
      document.body.style.cursor = 'url("https://raw.githubusercontent.com/Adrianchoparra/imgextension/main/cursor'+cursor+'.png"), auto';     
})